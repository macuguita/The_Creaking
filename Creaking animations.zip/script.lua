-- Auto generated script file --
require("animations")

--hide vanilla armor model
vanilla_model.ARMOR:setVisible(false)
vanilla_model.PLAYER:setVisible(false)
vanilla_model.CAPE:setPos(0, 4, -2)
