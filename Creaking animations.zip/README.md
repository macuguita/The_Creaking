# How to download
Click the big green code button and download as zip, add the zip to the figura folder and you should be able to select it and wear it.
